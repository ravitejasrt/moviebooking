package com.ticketbooking.api.enums;
public enum MovieType {
	COMEDY, CRIME, SUSPENSE, ROMANCE, THILLER
}
