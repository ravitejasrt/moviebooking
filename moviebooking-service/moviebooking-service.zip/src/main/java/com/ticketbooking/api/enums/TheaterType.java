package com.ticketbooking.api.enums;
public enum TheaterType {
	IMAX, PVR, LOCAL
}
