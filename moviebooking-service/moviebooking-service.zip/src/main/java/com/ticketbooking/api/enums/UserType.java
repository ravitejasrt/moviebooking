package com.ticketbooking.api.enums;

public enum UserType {
ADMIN,NORMAL
}
