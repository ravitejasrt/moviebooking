package com.ticketbooking.api.enums;
public enum Status {
	SUCCESS,FAILED,PROCESSING

}
