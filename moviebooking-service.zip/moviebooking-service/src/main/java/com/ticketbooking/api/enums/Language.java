package com.ticketbooking.api.enums;
public enum Language {
	HINDI, ENGLISH

}
