package com.ticketbooking.api.enums;
public enum PaymentMethod {
	CREDITCARD, DEBITCARD, INTERNETBANKING, PAYTM, AMAZONPAY, UPI
}
