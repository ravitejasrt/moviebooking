package com.ticketbooking.api.enums;
public enum NotificationType {
MOBILEPHONE,EMAIL,WATSAPP
}
