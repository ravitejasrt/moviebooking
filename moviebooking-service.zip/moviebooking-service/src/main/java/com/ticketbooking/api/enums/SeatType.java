package com.ticketbooking.api.enums;
public enum SeatType {
	NORMAL, VIP, EXECUTIVE, ROYAL, ENCLINER
}
