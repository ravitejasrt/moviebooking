package com.payment.api.controller;
public enum Status {
	SUCCESS,FAILED,PROCESSING

}
