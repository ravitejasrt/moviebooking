package com.payment.api.controller;
public enum PaymentMethod {
	CREDITCARD, DEBITCARD, INTERNETBANKING, PAYTM, AMAZONPAY, UPI
}
