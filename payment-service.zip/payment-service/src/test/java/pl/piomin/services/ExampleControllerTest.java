package pl.piomin.services;

import org.junit.Assert;
import org.junit.Test;

public class ExampleControllerTest {

    @Test
    public void test() throws Exception {
        Assert.assertTrue(true);
    }

}
